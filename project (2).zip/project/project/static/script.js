const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
const modeRadios = document.getElementsByName('mode');

function addMessage(content, isUser, type = 'text') {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(isUser ? 'user-message' : 'ai-message');
    
    if (type === 'text') {
        if (isUser) {
            messageDiv.textContent = content;
        } else {
            messageDiv.innerHTML = marked.parse(content);
        }
    } else if (type === 'image') {
        messageDiv.classList.add('image-message');
        const img = document.createElement('img');
        img.src = `data:image/png;base64,${content}`;
        messageDiv.appendChild(img);
    } else if (type === 'speech') {
        const audio = document.createElement('audio');
        audio.controls = true;
        audio.src = URL.createObjectURL(content);
        messageDiv.appendChild(audio);
    }
    
    chatMessages.appendChild(messageDiv);

    // Scroll to the bottom using scrollIntoView
    messageDiv.scrollIntoView({ behavior: 'smooth', block: 'end' });
}

async function sendMessage() {
    const message = userInput.value.trim();
    if (message) {
        addMessage(message, true);
        userInput.value = '';

        const mode = Array.from(modeRadios).find(radio => radio.checked).value;

        try {
            const response = await fetch('/query', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query: message, mode: mode }),
            });

            if (response.ok) {
                if (mode === 'text') {
                    const data = await response.json();
                    addMessage(data.response, false);
                } else if (mode === 'image') {
                    const data = await response.json();
                    addMessage(data.image, false, 'image');
                } else if (mode === 'speech') {
                    const blob = await response.blob();
                    addMessage(blob, false, 'speech');
                    const textResponse = await fetch('/query', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ query: message, mode: 'text' }),
                    });
                    const textData = await textResponse.json();
                    addMessage(textData.response, false);
                }
            } else {
                addMessage('Error: Unable to get response', false);
            }
        } catch (error) {
            console.error('Error:', error);
            addMessage('Error: Unable to send message', false);
        }
    }
}

sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});
